ConFoo 2026 - SQLite Talk

SQLite is the most widely deployed database in the world.
It runs everywhere: phones, browsers, embedded devices, and more.
hello from confoo
